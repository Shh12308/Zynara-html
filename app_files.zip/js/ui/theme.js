
import { state, setState } from '../core/state.js';

export function initUI() {
  const themeBtn = document.querySelector('#theme-btn');
  themeBtn.addEventListener('click', toggleTheme);
  applyTheme(state.ui.theme);
}

function toggleTheme() {
  const newTheme = state.ui.theme === 'light' ? 'dark' : 'light';
  setState('ui.theme', newTheme);
  localStorage.setItem('theme', newTheme);
  applyTheme(newTheme);
}

function applyTheme(theme) {
  document.documentElement.setAttribute('data-theme', theme);
}
