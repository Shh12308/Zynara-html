
export function initMedia() {
  const micBtn = document.querySelector('#mic-btn');
  micBtn.addEventListener('click', startRecording);
}

let mediaRecorder;
let audioChunks = [];

async function startRecording() {
  const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
  mediaRecorder = new MediaRecorder(stream);
  audioChunks = [];

  mediaRecorder.ondataavailable = e => audioChunks.push(e.data);
  mediaRecorder.onstop = exportAudio;

  mediaRecorder.start();
  setTimeout(() => mediaRecorder.stop(), 5000);
}

function exportAudio() {
  const audioBlob = new Blob(audioChunks);
  const url = URL.createObjectURL(audioBlob);
  const audio = new Audio(url);
  audio.play();
}
