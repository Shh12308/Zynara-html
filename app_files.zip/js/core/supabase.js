
import { createClient } from 'https://cdn.jsdelivr.net/npm/@supabase/supabase-js/+esm';
import { state, setState } from './state.js';

export const supabase = createClient(
  'YOUR_SUPABASE_URL',
  'YOUR_SUPABASE_ANON_KEY'
);

export async function initSupabase() {
  const { data: { session } } = await supabase.auth.getSession();
  setState('currentUser', session?.user || null);

  supabase.auth.onAuthStateChange((_event, session) => {
    setState('currentUser', session?.user || null);
  });
}
