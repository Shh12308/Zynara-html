
export const state = {
  currentUser: null,
  userPlan: 'free',
  currentChatId: null,
  isGenerating: false,
  abortController: null,
  folders: {
    unfiled: { name: 'Unfiled', chats: {} }
  },
  imageGallery: [],
  anonCount: Number(localStorage.getItem('anonMessageCount') || 0),
  ui: {
    theme: localStorage.getItem('theme') || 'light',
    modalsOpen: {},
    notifications: []
  },
  usage: {
    tokensUsed: 0,
    messagesSent: 0
  }
};

export const setState = (keyPath, value) => {
  const keys = keyPath.split('.');
  let obj = state;
  keys.slice(0, -1).forEach(k => {
    if (!(k in obj)) obj[k] = {};
    obj = obj[k];
  });
  obj[keys[keys.length - 1]] = value;
};
