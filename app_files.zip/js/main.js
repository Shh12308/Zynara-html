
import { state, setState } from './core/state.js';
import { initSupabase } from './core/supabase.js';
import { initChat } from './chat/chat-ui.js';
import { initMedia } from './media/voice.js';
import { initUI } from './ui/theme.js';

async function initApp() {
  await initSupabase();
  initUI();
  initMedia();
  initChat();

  console.log('App initialized:', state);
}

window.addEventListener('DOMContentLoaded', initApp);
