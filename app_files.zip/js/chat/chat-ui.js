
import { state, setState } from '../core/state.js';

export function initChat() {
  const chatInput = document.querySelector('#chat-input');
  const chatForm = document.querySelector('#chat-form');

  chatForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    const message = chatInput.value.trim();
    if (!message) return;

    addMessage('user', message);
    chatInput.value = '';

    setState('isGenerating', true);
    await generateAIResponse(message);
    setState('isGenerating', false);
  });
}

function addMessage(sender, text) {
  const chatBox = document.querySelector('#chat-box');
  const msg = document.createElement('div');
  msg.className = `message ${sender}`;
  msg.textContent = text;
  chatBox.appendChild(msg);
  chatBox.scrollTop = chatBox.scrollHeight;
}

async function generateAIResponse(message) {
  return new Promise(resolve => {
    setTimeout(() => {
      addMessage('ai', `Echo: ${message}`);
      resolve();
    }, 1000);
  });
}
